require 'cairo'

function draw_rounded_rect(cr, w, h, r)
    cairo_move_to(cr, r, 0)
    cairo_line_to(cr, w - r, 0)
    cairo_arc(cr, w - r, r, r, -math.pi/2, 0)
    cairo_line_to(cr, w, h - r)
    cairo_arc(cr, w - r, h - r, r, 0, math.pi/2)
    cairo_line_to(cr, r, h)
    cairo_arc(cr, r, h - r, r, math.pi/2, math.pi)
    cairo_line_to(cr, 0, r)
    cairo_arc(cr, r, r, r, math.pi, -math.pi/2)
    cairo_close_path(cr)
end

function conky_draw_rounded_background()
    if conky_window == nil then return end
    local cs = cairo_xlib_surface_create(conky_window.display, conky_window.drawable, conky_window.visual, conky_window.width, conky_window.height)
    local cr = cairo_create(cs)
    
    cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR)
    cairo_paint(cr)
    cairo_set_operator(cr, CAIRO_OPERATOR_OVER)

    local corner_radius = 15
    draw_rounded_rect(cr, conky_window.width, conky_window.height, corner_radius)
    
    cairo_set_source_rgba(cr, 0.0, 0.0, 0.0, 0.8) 
    cairo_fill(cr)
    
    cairo_destroy(cr)
    cairo_surface_destroy(cs)
end
